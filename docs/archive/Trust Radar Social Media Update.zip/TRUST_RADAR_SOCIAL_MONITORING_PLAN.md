# Trust Radar — Enterprise Social Brand Monitoring
## Platform Plan & Claude Code Implementation Spec

**Date:** March 2026
**Status:** Feature ~60% complete. Infrastructure done. Signal quality and UI are the gaps.
**Repo:** `packages/trust-radar` in `cleerox-svg/trust-radar` monorepo

---

## 1. Current State Assessment

### What already exists (do not rebuild)

| Layer | File | Status |
|---|---|---|
| Schema | `migrations/0030_social_monitoring.sql` | ✅ Complete — 3 tables, all indexes |
| API handlers | `src/handlers/socialMonitor.ts` | ✅ Complete — all 4 handlers, real SQL |
| Brand profiles CRUD | `src/handlers/brandProfiles.ts` | ✅ Complete — full CRUD + handle management |
| Scan pipeline | `src/scanners/social-monitor.ts` | ✅ Complete — single brand + batch cron runner |
| Routes | `src/index.ts` | ✅ Wired — all social routes registered |
| Alerts integration | `src/lib/alerts.ts` | ✅ HIGH/CRITICAL findings auto-create alerts |
| Audit logging | `src/lib/audit.ts` | ✅ All scan actions logged |

### What needs verification (audit before building)

| File | What to check |
|---|---|
| `src/lib/social-check.ts` | Is this real HEAD request logic or a stub? |
| `src/lib/handle-permutations.ts` | Does it generate meaningful variants? |
| `src/scanners/impersonation-scorer.ts` | Is the scoring logic real or placeholder? |
| `src/agents/sentinel.ts` | Is AI assessment wired to social findings? |
| `src/templates/social-dashboard.ts` | Does the UI exist or is it a stub? |
| `src/cron/orchestrator.ts` | Is `runSocialMonitorBatch` actually called? |

### The core signal gap

The scanner currently uses HTTP HEAD requests to check if a handle exists. This means three critical signals are always `false`:

```typescript
account_age_suspicious: false,  // Cannot determine from HEAD request
low_followers: false,           // Cannot determine from HEAD request  
verified: false,                // Assume not verified
```

This produces conservative scoring. An account named `@acme_official` with 12 followers and a logo stolen from Acme Corp gets the same `false` flags as a legitimate account. For enterprise-grade detection this is the primary gap to close.

---

## 2. The Signal Quality Problem — How to Solve It

### Current approach (HEAD requests only)
Check if `https://x.com/acmecorp_official` returns 200. Binary result — exists or doesn't.

### What we need (per platform strategy)

**X / Twitter**
- Use Twitter Basic API ($100/mo) OR RapidAPI Twitter wrapper (~$10/mo)
- Gets: follower count, account creation date, verified status, profile description, pinned tweet
- Alternative: Nitter public instance scraping (fragile but free)
- **Recommended:** RapidAPI `Twitter API v2` endpoint — `GET /users/by/username/{username}`

**Instagram**
- No official public API for non-business accounts
- RapidAPI `Instagram Scraper` (~$10-20/mo) — returns follower count, bio, verified, profile pic URL
- Alternative: Apify Instagram public actor (pay-per-run, ~$0.001/profile)
- **Recommended:** Apify for cost control — only scrape when impersonation score > 0.3 from handle check

**TikTok**
- TikTok Research API (free, apply at developers.tiktok.com) — gets full profile data
- Alternative: RapidAPI TikTok scraper (~$10/mo)
- **Recommended:** Apply for Research API first; fall back to RapidAPI

**LinkedIn**
- Most restrictive — no public API for profile scraping
- Can check company page existence via HEAD request to `linkedin.com/company/{handle}`
- For deeper signals: check if the page has employees listed (public count visible)
- **Recommended:** HEAD check only for now — LinkedIn impersonation is lower risk for most brands

**YouTube**
- YouTube Data API v3 (free — 10,000 units/day)
- `GET /channels?part=snippet,statistics&forHandle=@handle`
- Gets: subscriber count, channel creation date, verified, description
- **Recommended:** Full API — it's free and rich

**GitHub**
- GitHub API (free, 60 req/hr unauthenticated, 5000/hr authenticated)
- `GET /users/{username}` or `GET /orgs/{org}`
- Gets: follower count, creation date, bio, verified
- **Recommended:** Full API — free and important for tech brands

### Enrichment trigger logic

Don't enrich every found account — that burns API quota. Use a two-pass approach:

```
Pass 1: HEAD check (free)
  → handle exists AND name_similarity > 0.6 → trigger Pass 2

Pass 2: API enrichment (costs money)
  → fetch follower count, account age, verified status
  → re-score with full signals
  → store enriched result
```

This means API calls only happen for accounts that already look suspicious from the name alone.

---

## 3. AI Agent Integration — Sentinel

The `sentinel.ts` agent should be the AI layer for social monitoring. Based on the agent naming convention in the codebase (analyst, observer, narrator, cartographer, prospector, strategist), Sentinel's role is threat validation — confirming whether a found account is genuinely suspicious or a false positive.

### Sentinel's job for social monitoring

**Input:** A `social_monitor_result` record with all signals
**Output:** Structured AI assessment with:
- `confirmed_impersonation: boolean`
- `confidence: 0.0-1.0`
- `reasoning: string` (plain English for the dashboard)
- `recommended_action: 'monitor' | 'report' | 'legal_notice' | 'dismiss'`
- `evidence_summary: string` (pre-drafted text for platform report submission)

### Haiku prompt structure for Sentinel social assessment

```
You are a brand protection analyst. Evaluate whether this social media account 
is impersonating the brand described below.

BRAND:
- Name: {brand_name}
- Domain: {domain}
- Official {platform} handle: {official_handle}

SUSPICIOUS ACCOUNT:
- Handle: {handle_checked}
- Platform: {platform}
- Exists: Yes (confirmed)
- Follower count: {follower_count ?? 'unknown'}
- Account age: {account_age_days ?? 'unknown'} days
- Verified: {verified}
- Bio excerpt: {bio_snippet ?? 'not available'}
- Profile image similarity: {avatar_similarity_score ?? 'not checked'}

IMPERSONATION SIGNALS DETECTED:
{impersonation_signals as bullet list}
Raw score: {impersonation_score * 100}%

Assess:
1. Is this account likely impersonating the brand? (true/false)
2. Confidence level (0.0 to 1.0)
3. Your reasoning in 1-2 sentences
4. Recommended action: monitor | report | legal_notice | dismiss
5. If report or legal_notice: draft a one-paragraph report summary for the platform

Respond in JSON only.
```

### When Sentinel runs

- Automatically after every scan result with severity HIGH or CRITICAL
- On-demand via `/api/social/monitor/:brandId/assess/:resultId`
- Batch: during cron run, after all results stored, process unassessed HIGH/CRITICAL

---

## 4. New Signals to Add

Beyond the core scanner, these additional signals make the platform genuinely enterprise-grade and differentiated:

### 4.1 Executive / C-Suite Impersonation
The `brand_profiles` schema already has `executive_names TEXT (JSON array)`. Use it.

- When a brand has `executive_names: ["John Smith", "Jane Doe"]`, also scan for personal impersonation handles: `@johnsmith_ceo`, `@realjanedoe`, `@janedoe_official`
- Same pipeline: generate permutations of each executive name, run handle checks, score, alert
- This is a differentiating feature — most mid-market brands don't know their CFO's name is being squatted on TikTok

### 4.2 Logo / Avatar Similarity
The `brand_profiles` schema has `logo_hash TEXT` (perceptual hash). Wire it.

- When enriching a suspicious account (Pass 2), fetch their profile picture
- Compute perceptual hash of fetched avatar
- Compare against `logo_hash` in brand_profiles
- A stolen logo = near-certain impersonation regardless of other signals
- Library: `@resvg/resvg-wasm` for image processing in CF Workers, or do hash comparison server-side in Railway API
- This turns `uses_brand_logo: boolean` from always-false to actually meaningful

### 4.3 Cross-Platform Consistency Score
If the same suspicious handle appears on 3+ platforms, that's a coordinated campaign — escalate severity.

```sql
SELECT handle_checked, COUNT(DISTINCT platform) as platform_count
FROM social_monitor_results
WHERE brand_id = ? AND status = 'open'
GROUP BY handle_checked
HAVING platform_count >= 2
```

Auto-escalate any handle found on 2+ platforms to at least HIGH. Found on 3+ → CRITICAL.

### 4.4 Threat Feed Correlation
Trust Radar already has domain threat feeds. Cross-reference:

- If a suspicious social account links to a domain in the threat feed → escalate to CRITICAL
- If a suspicious handle matches a domain we've already flagged → near-certain malicious
- This is unique to Trust Radar — no other social monitoring tool has this correlation

### 4.5 New Registered Domain Correlation
Trust Radar already monitors newly registered domains. If a new domain `brand-name-official.com` appears AND a social account `@brandnameofficial` appears in the same week → coordinated attack signal.

Query against `threat_signals` (already exists) for domain patterns matching brand keywords.

---

## 5. Data Model Additions

The existing schema is solid. These are additive migrations only — no changes to existing tables.

### Migration 0035 — Social monitoring enrichment

```sql
-- Add enrichment fields to social_monitor_results
ALTER TABLE social_monitor_results ADD COLUMN follower_count INTEGER;
ALTER TABLE social_monitor_results ADD COLUMN account_age_days INTEGER;
ALTER TABLE social_monitor_results ADD COLUMN bio_snippet TEXT;
ALTER TABLE social_monitor_results ADD COLUMN avatar_url TEXT;
ALTER TABLE social_monitor_results ADD COLUMN avatar_hash TEXT;
ALTER TABLE social_monitor_results ADD COLUMN verified INTEGER DEFAULT 0;
ALTER TABLE social_monitor_results ADD COLUMN ai_confidence REAL;
ALTER TABLE social_monitor_results ADD COLUMN ai_action TEXT; -- monitor|report|legal_notice|dismiss
ALTER TABLE social_monitor_results ADD COLUMN ai_evidence_draft TEXT;
ALTER TABLE social_monitor_results ADD COLUMN enriched_at TEXT;
ALTER TABLE social_monitor_results ADD COLUMN cross_platform_count INTEGER DEFAULT 1;

-- Executive name monitoring results (linked to brand)
CREATE TABLE IF NOT EXISTS executive_monitor_results (
  id TEXT PRIMARY KEY,
  brand_id TEXT NOT NULL REFERENCES brand_profiles(id),
  executive_name TEXT NOT NULL,
  platform TEXT NOT NULL,
  handle_checked TEXT NOT NULL,
  handle_available INTEGER,
  impersonation_score REAL,
  severity TEXT DEFAULT 'LOW',
  status TEXT DEFAULT 'open',
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_exec_results_brand
  ON executive_monitor_results(brand_id);
CREATE INDEX IF NOT EXISTS idx_exec_results_severity
  ON executive_monitor_results(severity, status);
```

---

## 6. API Endpoints — Additions

The existing 4 endpoints are sufficient for core functionality. These additions complete the feature:

```
GET  /api/social/overview              → handleSocialOverview (EXISTS)
GET  /api/social/monitor/:brandId      → handleBrandSocialMonitor (EXISTS)
GET  /api/social/alerts                → handleSocialAlerts (EXISTS)
POST /api/social/scan/:brandId         → handleTriggerSocialScan (EXISTS)

--- NEW ---
POST /api/social/assess/:resultId      → Trigger Sentinel AI assessment on a result
PATCH /api/social/results/:id          → Update result status (resolve, false_positive)
GET  /api/social/results/:id           → Get single result with full detail + AI assessment
GET  /api/social/executives/:brandId   → Executive monitoring results
GET  /api/social/cross-platform        → Cross-platform handle matches (coordinated attacks)
GET  /api/social/platforms/:brandId    → Per-platform status summary (SECURED/ALERT/UNCLAIMED)
```

---

## 7. Cron Integration

The batch runner `runSocialMonitorBatch` exists. Verify it's called in `src/cron/orchestrator.ts`.

If not already there, add to the cron orchestrator:

```typescript
// Social brand monitoring — runs every 6 hours
// Check the hour to stagger with other cron tasks
if (hour % 6 === 0) {
  tasks.push(
    runSocialMonitorBatch(env).catch(err =>
      logger.error('cron_social_monitor_failed', { error: String(err) })
    )
  );
}
```

After each batch run, trigger Sentinel for any unassessed HIGH/CRITICAL results:

```typescript
// AI assessment pass — after social monitor batch
await runSentinelSocialAssessment(env); // new function in sentinel.ts
```

---

## 8. Dashboard UI

The `renderSocialDashboard` template is imported in `index.ts`. Whether it's a stub or real, it must be fully replaced with the spec below. This is a **server-rendered TypeScript template** returning an HTML string — same pattern as all other Trust Radar templates. All JS is inline `<script>` tags. No build step, no React, no bundler.

---

### 8.1 Design System

**Inherit from Trust Radar** — do not invent a new palette.

```css
/* Trust Radar tokens — already defined globally, reuse exactly */
--tr-bg:         #F8F9FA;   /* light mode page background */
--tr-surface:    #FFFFFF;   /* card surfaces */
--tr-border:     #E5E7EB;   /* borders */
--tr-text:       #111827;   /* primary text */
--tr-text-2:     #6B7280;   /* secondary text */
--tr-teal:       #0D9488;   /* primary accent — secured/safe */
--tr-teal-light: #CCFBF1;   /* teal tint for backgrounds */
--tr-coral:      #EF4444;   /* alert/critical */
--tr-coral-light:#FEE2E2;   /* coral tint */
--tr-amber:      #F59E0B;   /* warning/medium */
--tr-amber-light:#FEF3C7;   /* amber tint */
--tr-green:      #10B981;   /* resolved/success */
--tr-mono:       'IBM Plex Mono', monospace;
--tr-display:    'Syne', sans-serif;
--tr-body:       'DM Sans', sans-serif;
```

**Dark mode:** Trust Radar uses a dark toggle. The social dashboard must honour it. Use `prefers-color-scheme` + a `data-theme="dark"` attribute on `<html>` for the manual toggle. Every colour must have a dark variant defined.

---

### 8.2 Layout — Mobile-First Responsive Grid

**Philosophy:** Mobile is the primary viewport for security teams checking alerts on-the-go. The layout must be fully functional at 375px and beautiful at 1440px. No horizontal scrolling. No truncation without a tap-to-expand affordance.

```
Mobile  (< 640px):   Single column. Bottom sheet drawers instead of sidepanels.
                     Sticky summary bar at top showing critical count.
                     FAB (floating action button) for "Add Brand".

Tablet  (640–1024px): Two-column brand grid. Alert feed below.
                      Slide-in drawer for brand detail (50% width).

Desktop (> 1024px):  Three-column brand grid + fixed right rail for alert feed.
                     Full-width brand detail in a slide-over panel (40% width).
```

CSS implementation — use CSS Grid with `auto-fill` and `minmax`, not fixed breakpoints for the brand grid:

```css
.brand-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(min(100%, 320px), 1fr));
  gap: 16px;
}
```

This produces 1 column on mobile, 2 on tablet, 3 on desktop — automatically, with no media queries needed for the grid itself.

---

### 8.3 Page Structure

```
┌─────────────────────────────────────────────────────┐
│  Sticky Summary Bar (mobile: always visible)        │
│  [2 CRITICAL] [5 HIGH] [12 brands monitored] [+Add] │
├─────────────────────────────────────────────────────┤
│  Page Header                                        │
│  "Social Brand Monitor"  Last scan: 4 min ago       │
├──────────────────────────────┬──────────────────────┤
│                              │                      │
│   Brand Coverage Grid        │  Alert Feed Rail     │
│   (auto-fill, 320px min)     │  (desktop only —     │
│                              │   fixed right rail)  │
│   [Card] [Card] [Card]       │                      │
│   [Card] [Card]              │  [Alert]             │
│                              │  [Alert]             │
│                              │  [Alert]             │
│                              │                      │
├──────────────────────────────┴──────────────────────┤
│  Alert Feed (mobile + tablet — below grid)          │
│  [Alert row] [Alert row] [Alert row]                │
└─────────────────────────────────────────────────────┘

On brand card tap/click:
→ Detail drawer slides in from right (desktop/tablet)
→ Bottom sheet slides up (mobile)
```

---

### 8.4 Advanced Visual Techniques

Claude Code must implement ALL of the following. These are not optional polish — they are what separates this from generic SaaS UI.

#### Platform Status Pills — Animated State Indicators

Each platform pill (SECURED / ALERT / UNCLAIMED / SCANNING) must use CSS-only state animations:

```css
/* ALERT state — pulsing dot */
.platform-pill.alert .status-dot {
  background: var(--tr-coral);
  animation: threat-pulse 2s ease-in-out infinite;
  box-shadow: 0 0 0 0 rgba(239,68,68,0.4);
}
@keyframes threat-pulse {
  0%   { box-shadow: 0 0 0 0 rgba(239,68,68,0.4); }
  70%  { box-shadow: 0 0 0 6px rgba(239,68,68,0); }
  100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
}

/* SCANNING state — rotating arc */
.platform-pill.scanning .status-dot {
  background: transparent;
  border: 2px solid var(--tr-teal);
  border-top-color: transparent;
  animation: spin 1s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* SECURED state — subtle shimmer on hover */
.platform-pill.secured:hover {
  background: linear-gradient(90deg, var(--tr-teal-light), #e0fdf4, var(--tr-teal-light));
  background-size: 200% 100%;
  animation: shimmer 1.5s ease-in-out;
}
@keyframes shimmer {
  0%   { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
```

#### Risk Score Arc — SVG Gauge per Brand Card

Each brand card shows a circular SVG arc gauge for the social risk score (0–100), not a plain number:

```html
<!-- Inline SVG gauge — no external library needed -->
<svg class="risk-gauge" viewBox="0 0 60 60" width="60" height="60">
  <!-- Background track -->
  <circle cx="30" cy="30" r="24"
    fill="none" stroke="var(--tr-border)" stroke-width="4"
    stroke-dasharray="113" stroke-dashoffset="28"
    transform="rotate(135 30 30)"/>
  <!-- Score arc — dashoffset computed from score -->
  <circle cx="30" cy="30" r="24"
    fill="none" stroke="var(--score-color)" stroke-width="4"
    stroke-linecap="round"
    stroke-dasharray="113"
    stroke-dashoffset="var(--score-offset)"  <!-- set via inline style from score -->
    transform="rotate(135 30 30)"
    style="transition: stroke-dashoffset 1s cubic-bezier(0.4,0,0.2,1)"/>
  <!-- Score label -->
  <text x="30" y="34" text-anchor="middle"
    font-family="var(--tr-display)" font-size="12" font-weight="700"
    fill="var(--score-color)">72</text>
</svg>
```

Score offset formula: `stroke-dashoffset = 113 - (score / 100 * 113)`
Color: 0–39 green, 40–69 amber, 70–89 coral, 90–100 red.

JavaScript sets `--score-offset` and `--score-color` as inline CSS vars per card. Animate on load with a brief delay per card for staggered entrance.

#### Brand Card — Glass Morphism Surface with Severity Tint

```css
.brand-card {
  background: var(--tr-surface);
  border: 1px solid var(--tr-border);
  border-radius: 16px;
  padding: 20px;
  position: relative;
  overflow: hidden;
  transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
  cursor: pointer;
}

/* Top edge accent — severity tint */
.brand-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  border-radius: 16px 16px 0 0;
}
.brand-card.critical::before { background: linear-gradient(90deg, #EF4444, #F97316); }
.brand-card.high::before     { background: linear-gradient(90deg, #F97316, #F59E0B); }
.brand-card.medium::before   { background: linear(90deg, #F59E0B, #EAB308); }
.brand-card.low::before      { background: linear-gradient(90deg, #10B981, #0D9488); }
.brand-card.clear::before    { background: linear-gradient(90deg, #0D9488, #06B6D4); }

/* Hover lift */
.brand-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.08);
  border-color: var(--tr-teal);
}

/* CRITICAL state — subtle red wash in background */
.brand-card.critical {
  background: linear-gradient(160deg, rgba(254,226,226,0.4) 0%, var(--tr-surface) 40%);
}

/* Dark mode */
[data-theme="dark"] .brand-card {
  background: #1a1a2e;
  border-color: #2d2d4a;
}
[data-theme="dark"] .brand-card.critical {
  background: linear-gradient(160deg, rgba(127,29,29,0.2) 0%, #1a1a2e 40%);
}
```

#### Alert Feed — Severity-Banded Timeline

Each alert row has a left-edge severity band, not just a badge:

```css
.alert-row {
  position: relative;
  padding: 14px 16px 14px 20px;
  border-bottom: 1px solid var(--tr-border);
  transition: background 0.15s;
}
.alert-row::before {
  content: '';
  position: absolute;
  left: 0; top: 0; bottom: 0;
  width: 4px;
  border-radius: 0 2px 2px 0;
}
.alert-row.critical::before { background: var(--tr-coral); }
.alert-row.high::before     { background: #F97316; }
.alert-row.medium::before   { background: var(--tr-amber); }
.alert-row.low::before      { background: var(--tr-teal); }

.alert-row:hover { background: var(--tr-bg); }

/* NEW badge — flash animation for alerts < 5 min old */
.alert-row.fresh .new-badge {
  animation: flash-in 0.4s ease-out;
}
@keyframes flash-in {
  from { opacity: 0; transform: scale(0.8); }
  to   { opacity: 1; transform: scale(1); }
}
```

#### Detail Drawer — Slide-In Animation

```css
.detail-drawer {
  position: fixed;
  top: 0; right: 0; bottom: 0;
  width: min(480px, 100vw);
  background: var(--tr-surface);
  box-shadow: -8px 0 32px rgba(0,0,0,0.12);
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  z-index: 50;
  overflow-y: auto;
  overscroll-behavior: contain;  /* prevents body scroll bleed on mobile */
}
.detail-drawer.open { transform: translateX(0); }

/* Mobile: Bottom sheet instead */
@media (max-width: 640px) {
  .detail-drawer {
    top: auto;
    left: 0; right: 0;
    height: 85dvh;  /* dvh = dynamic viewport height — handles mobile browser chrome */
    width: 100%;
    border-radius: 20px 20px 0 0;
    transform: translateY(100%);
  }
  .detail-drawer.open { transform: translateY(0); }

  /* Drag handle */
  .drawer-handle {
    width: 36px; height: 4px;
    background: var(--tr-border);
    border-radius: 2px;
    margin: 12px auto 0;
  }
}

/* Backdrop */
.drawer-backdrop {
  position: fixed; inset: 0;
  background: rgba(0,0,0,0.3);
  backdrop-filter: blur(2px);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s;
  z-index: 49;
}
.drawer-backdrop.visible {
  opacity: 1;
  pointer-events: all;
}
```

#### Impersonation Score Bar — Animated Fill

Inside the detail drawer, each finding shows a score bar:

```css
.score-bar-track {
  height: 6px;
  background: var(--tr-border);
  border-radius: 3px;
  overflow: hidden;
}
.score-bar-fill {
  height: 100%;
  border-radius: 3px;
  width: 0%;  /* set via JS after drawer opens */
  transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1) var(--delay, 0ms);
}
```

Stagger each signal bar's animation with a CSS variable `--delay` set inline: `style="--delay: 100ms"`, `200ms`, etc. Drawer open → 50ms pause → bars animate in sequence.

#### Sticky Summary Bar

```css
.summary-bar {
  position: sticky;
  top: 0;
  z-index: 30;
  background: rgba(248,249,250,0.9);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--tr-border);
  padding: 10px 16px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

/* Severity chips in the bar */
.severity-chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-family: var(--tr-mono);
  font-weight: 500;
  white-space: nowrap;
}
.severity-chip.critical { background: var(--tr-coral-light); color: var(--tr-coral); }
.severity-chip.high     { background: #FFEDD5; color: #EA580C; }
.severity-chip.medium   { background: var(--tr-amber-light); color: #B45309; }
```

Dark mode for sticky bar:
```css
[data-theme="dark"] .summary-bar {
  background: rgba(10,10,20,0.9);
  border-bottom-color: #2d2d4a;
}
```

---

### 8.5 Mobile-Specific Interactions

**Touch targets:** All tappable elements minimum 44×44px. Platform pills on mobile: minimum `height: 36px`, `padding: 8px 12px`. This is a hard requirement for WCAG 2.5.5.

**Swipe to dismiss alert:** On mobile, alert rows support swipe-left to reveal action buttons (Mark False Positive / Report). Implement with `TouchEvent` listeners — no library needed:

```javascript
// Pseudo-code — Claude Code writes the full implementation
alertRow.addEventListener('touchstart', recordStartX);
alertRow.addEventListener('touchmove', (e) => {
  const deltaX = e.touches[0].clientX - startX;
  if (deltaX < -20) revealActions(alertRow, Math.min(-deltaX, 140));
});
alertRow.addEventListener('touchend', snapOrReset);
```

**Pull-to-refresh:** The brand grid supports pull-to-refresh on mobile to trigger a new overview fetch:

```javascript
// Detect overscroll at top of page
// Show a subtle "↻ Refreshing..." indicator
// Call GET /api/social/monitor → re-render brand cards
```

**FAB (Floating Action Button) for Add Brand:**

```css
.fab {
  position: fixed;
  bottom: max(24px, env(safe-area-inset-bottom) + 16px); /* respects iPhone home bar */
  right: 20px;
  width: 56px; height: 56px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--tr-teal), #06B6D4);
  color: white;
  font-size: 24px;
  box-shadow: 0 4px 16px rgba(13,148,136,0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  border: none;
  transition: transform 0.2s, box-shadow 0.2s;
  z-index: 40;
}
.fab:active {
  transform: scale(0.94);
  box-shadow: 0 2px 8px rgba(13,148,136,0.3);
}

/* Hide FAB on desktop — use header button instead */
@media (min-width: 1024px) { .fab { display: none; } }
```

**Bottom navigation (mobile only):** On screens < 640px, add a bottom nav bar replacing the desktop sidebar tabs:

```css
.bottom-nav {
  display: none;
  position: fixed;
  bottom: 0; left: 0; right: 0;
  background: var(--tr-surface);
  border-top: 1px solid var(--tr-border);
  padding: 8px 0 max(8px, env(safe-area-inset-bottom));
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  z-index: 30;
}
@media (min-width: 640px) { .bottom-nav { display: none; } }

/* Tabs: Overview / Brands / Alerts / Settings */
.bottom-nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
  padding: 4px 0;
  font-size: 10px;
  color: var(--tr-text-2);
  cursor: pointer;
}
.bottom-nav-item.active { color: var(--tr-teal); }
```

---

### 8.6 Page Load Performance

Trust Radar templates are server-rendered HTML strings. The social dashboard must:

- **Skeleton screens** — show placeholder cards with shimmer animation while data loads via `fetch()`:

```css
.skeleton {
  background: linear-gradient(90deg, var(--tr-border) 25%, #f0f0f0 50%, var(--tr-border) 75%);
  background-size: 400% 100%;
  animation: skeleton-shimmer 1.4s ease-in-out infinite;
  border-radius: 8px;
}
@keyframes skeleton-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
```

- **Intersection Observer for brand cards** — only animate cards as they enter viewport, not all at once. Stagger entrance with `animation-delay`:

```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      entry.target.style.animationDelay = `${i * 60}ms`;
      entry.target.classList.add('card-enter');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.brand-card').forEach(c => observer.observe(c));
```

```css
@keyframes card-enter {
  from { opacity: 0; transform: translateY(12px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card-enter { animation: card-enter 0.3s ease-out forwards; }
```

- **Critical CSS inline** — all above-the-fold styles in `<style>` in `<head>`. Fonts loaded with `font-display: swap`.

---

### 8.7 Platform Report URLs

Pre-built report shortcuts — displayed as buttons in the detail drawer:

```typescript
const PLATFORM_REPORT_URLS: Record<string, string> = {
  twitter:   'https://help.twitter.com/forms/impersonation',
  instagram: 'https://www.instagram.com/help/contact/454951664593029',
  tiktok:    'https://www.tiktok.com/legal/report/user',
  linkedin:  'https://www.linkedin.com/help/linkedin/answer/30200',
  youtube:   'https://support.google.com/youtube/answer/2801947',
  github:    'https://support.github.com/contact/report-abuse',
};
```

"Report to Platform" button opens in new tab + logs the action via `PATCH /api/social/results/:id` with `status: 'investigating'`.

---

## 9. Integration With Existing Trust Radar Features

Social monitoring should NOT be a silo. Wire into these existing systems:

### Brand risk score
The `brand_profiles` table already has `social_risk_score INTEGER`. Update it after every scan:

```typescript
// Compute: weighted average of open finding severities
// CRITICAL=100, HIGH=75, MEDIUM=40, LOW=10
// Weighted by recency (last 30 days weighted 2x)
await env.DB.prepare(`
  UPDATE brand_profiles
  SET social_risk_score = ?,
      updated_at = datetime('now')
  WHERE id = ?
`).bind(computedScore, brandId).run();
```

The `exposure_score` (overall brand risk) should factor `social_risk_score` into its calculation.

### Analyst agent
When the Analyst agent assesses a brand, it should receive social monitoring context:
- Count of open social findings by severity
- Platforms with ALERT status
- Whether executive names are being impersonated
- Cross-platform handle matches (coordinated attack signal)

Add to Analyst's brand assessment prompt:
```
SOCIAL MONITORING:
- Open social findings: {critical} CRITICAL, {high} HIGH, {medium} MEDIUM
- Platforms at risk: {comma list of platforms with open HIGH+ findings}
- Executive impersonation: {yes/no}
- Coordinated (multi-platform): {yes/no}
```

### Threat correlation
Wire `runThreatFeedCorrelation` against social findings:
- Extract any URLs from `suspicious_account_url`
- Check associated domains against `threat_signals`
- If domain match found: escalate social result to CRITICAL, add `threat_feed_correlation: true` to signals

### Observer briefing
The Observer daily briefing should include a social monitoring section:
```
SOCIAL THREATS:
• {N} new impersonation findings across {M} brands
• Highest risk: {brand_name} — {N} CRITICAL findings on {platforms}
• New this week: {list of new suspicious handles}
• Resolved: {N} findings closed
```

---

## 10. Build Phases

### Phase 1 — Audit & Complete Core (run first)

Claude Code instructions:

1. **Audit** `src/lib/social-check.ts`, `src/lib/handle-permutations.ts`, `src/scanners/impersonation-scorer.ts` — report what exists, identify any stubs
2. **Audit** `src/agents/sentinel.ts` — does it handle social assessments? If not, add `runSentinelSocialAssessment` function
3. **Audit** `src/cron/orchestrator.ts` — is `runSocialMonitorBatch` called? If not, add it at 6-hour interval
4. **Audit** `src/templates/social-dashboard.ts` — is it a real template or stub? If stub, build it per spec in section 8
5. **Fix** any TypeScript compile errors across all social-related files
6. **Verify** `/api/social/monitor` routes return data correctly (manual test with a seeded brand)

### Phase 2 — Signal Enrichment

1. Add two-pass enrichment logic to `social-monitor.ts`:
   - Pass 1: existing HEAD check
   - Pass 2: RapidAPI enrichment when `name_similarity > 0.6`
2. Add YouTube Data API v3 integration (free)
3. Add GitHub API integration (free)
4. Add `src/lib/social-enrich.ts` with per-platform enrichment functions
5. Run migration 0035 to add enrichment columns to `social_monitor_results`
6. Update Sentinel prompt to use enriched signal data

### Phase 3 — Advanced Signals

1. Executive name monitoring — scan `executive_names` from brand_profiles
2. Cross-platform correlation query — auto-escalate coordinated handles
3. Threat feed correlation — check social URLs against threat_signals
4. Logo hash comparison (if R2 avatar storage is available)
5. NRD correlation — link new domain registrations to social handle activity

### Phase 4 — Dashboard & UX

1. Complete/replace `renderSocialDashboard` template
2. Platform status pills (SECURED / ALERT / UNCLAIMED)
3. Evidence draft copy button
4. Platform report URL shortcuts
5. Add social monitoring summary to Observer briefing
6. Add social context to Analyst agent brand assessment

---

## 11. Cost Estimate (Monthly)

| Service | Cost | Notes |
|---|---|---|
| RapidAPI Instagram scraper | ~$10-20 | Only for enrichment pass (not every check) |
| RapidAPI Twitter/X | ~$10 | OR Twitter Basic API at $100 |
| TikTok Research API | Free | Requires application approval |
| YouTube Data API v3 | Free | 10K units/day |
| GitHub API | Free | 5K req/hr authenticated |
| LinkedIn | Free | HEAD check only |
| Extra Haiku calls (Sentinel) | ~$3-8 | Only HIGH/CRITICAL findings get assessed |
| **Total new spend** | **~$23-38/mo** | Within platform cost targets |

---

## 12. What This Document Does NOT Cover

- imprsn8 — this is Trust Radar only. See `PRODUCT_BOUNDARIES.md`
- Individual creator/influencer monitoring — that is imprsn8's domain
- DMCA generation — that is imprsn8's domain
- Multi-tenant org architecture — separate workstream (`TRUST_RADAR_TENANT_ARCHITECTURE.md`)

---

*Review and approve before running any Claude Code session against trust-radar social monitoring.*
